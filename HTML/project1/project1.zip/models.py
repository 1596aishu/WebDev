from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, String, Integer
from sqlalchemy.ext.declarative import declarative_base

# db = SQLAlchemy()
Base = declarative_base()

class USER(Base):
   __tablename__ = 'user'
   username = Column(String(50), primary_key=True)
   password = Column(String(50))  
   timestamp = Column(Integer, nullable=False) 
   def __init__(self, username, password, timestamp):
      self.username = username
      self.password = password
      self.timestamp = timestamp
   def __repr__(self):
      return '<USER %r>' % (self.username)

class BOOK(Base):
   __tablename__ = 'book'
   isbn = Column(String(50), primary_key=True)
   bname = Column(String(50))  
   author = Column(String(50)) 
   year = Column(String(50))
   def __init__(self, isbn, bname, author, year):
      self.isbn = isbn
      self.bname = bname
      self.author = author
      self.year = year
   def __repr__(self):
      return '<BOOK %r>' % (self.isbn)
